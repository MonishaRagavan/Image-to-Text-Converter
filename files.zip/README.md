# Image to Text Converter

**Definition:** A program that extracts readable text from images using Optical Character Recognition (OCR).

**Tanglish:** Photo or scanned document-la irukkura text-ai extract pannalaam.

## How it works

1. **Load image** (OpenCV)
2. **Image processing**: grayscale, upscale, denoise, adaptive threshold, deskew
3. **OCR**: Tesseract engine (via `pytesseract`) recognises characters
4. **Output**: text printed, optionally saved to `.txt`, plus a confidence score

## Python libraries

| Library | Purpose |
|---|---|
| `opencv-python` | image processing |
| `numpy` | array operations on images |
| `pytesseract` | Python wrapper for Tesseract OCR |

## Setup

```bash
pip install -r requirements.txt
```

Install the Tesseract engine itself:

- **Windows:** https://github.com/UB-Mannheim/tesseract/wiki (then set the path in `ocr_converter.py`)
- **macOS:** `brew install tesseract tesseract-lang`
- **Ubuntu/Debian:** `sudo apt install tesseract-ocr tesseract-ocr-tam`

## Usage

```bash
python ocr_converter.py photo.jpg
python ocr_converter.py scan.png --output result.txt
python ocr_converter.py tamil_sign.jpg --lang tam          # Tamil
python ocr_converter.py mixed.jpg --lang eng+tam           # English + Tamil
python ocr_converter.py scan.png --show                    # preview preprocessing
```

## Tips for better accuracy

- Use a well-lit, straight-on photo; 300 DPI for scans.
- Try `--psm 6` for a single block of text, `--psm 7` for one line.
- Compare with `--no-preprocess`; clean images sometimes do better untouched.

## Ideas to extend

- Add a GUI (Tkinter) or web app (Streamlit/Flask)
- Batch-process a whole folder
- Support PDFs via `pdf2image`
- Export to Word/PDF, or add translation
