"""
Image to Text Converter
-----------------------
Extracts readable text from photos or scanned documents using OCR
(Tesseract via pytesseract) with OpenCV preprocessing.

Usage:
    python ocr_converter.py photo.jpg
    python ocr_converter.py scan.png --lang eng+tam --output result.txt
    python ocr_converter.py scan.png --show     # preview the preprocessed image
"""

import argparse
import sys
from pathlib import Path

import cv2
import numpy as np
import pytesseract

# Windows only: uncomment and set the path if Tesseract isn't on your PATH
# pytesseract.pytesseract.tesseract_cmd = r"C:\Program Files\Tesseract-OCR\tesseract.exe"


# ---------------------------------------------------------------------------
# 1. Image processing
# ---------------------------------------------------------------------------
def load_image(path: str) -> np.ndarray:
    image = cv2.imread(path)
    if image is None:
        raise FileNotFoundError(f"Could not read image: {path}")
    return image


def to_grayscale(image: np.ndarray) -> np.ndarray:
    return cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)


def upscale_if_small(gray: np.ndarray, min_width: int = 1000) -> np.ndarray:
    """OCR works best when characters are reasonably large."""
    h, w = gray.shape
    if w < min_width:
        scale = min_width / w
        gray = cv2.resize(gray, None, fx=scale, fy=scale, interpolation=cv2.INTER_CUBIC)
    return gray


def remove_noise(gray: np.ndarray) -> np.ndarray:
    return cv2.fastNlMeansDenoising(gray, None, h=15)


def binarize(gray: np.ndarray) -> np.ndarray:
    """Adaptive threshold handles uneven lighting (typical in phone photos)."""
    return cv2.adaptiveThreshold(
        gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 31, 11
    )


def deskew(binary: np.ndarray) -> np.ndarray:
    """Straighten slightly rotated scans."""
    coords = np.column_stack(np.where(binary < 128))
    if len(coords) < 50:
        return binary
    angle = cv2.minAreaRect(coords)[-1]
    angle = -(90 + angle) if angle < -45 else -angle
    if abs(angle) < 0.5:
        return binary
    h, w = binary.shape
    matrix = cv2.getRotationMatrix2D((w // 2, h // 2), angle, 1.0)
    return cv2.warpAffine(
        binary, matrix, (w, h), flags=cv2.INTER_CUBIC, borderMode=cv2.BORDER_REPLICATE
    )


def preprocess(image: np.ndarray) -> np.ndarray:
    gray = to_grayscale(image)
    gray = upscale_if_small(gray)
    gray = remove_noise(gray)
    binary = binarize(gray)
    return deskew(binary)


# ---------------------------------------------------------------------------
# 2. OCR
# ---------------------------------------------------------------------------
def extract_text(image: np.ndarray, lang: str = "eng", psm: int = 3) -> str:
    config = f"--oem 3 --psm {psm}"
    return pytesseract.image_to_string(image, lang=lang, config=config).strip()


def average_confidence(image: np.ndarray, lang: str = "eng") -> float:
    data = pytesseract.image_to_data(image, lang=lang, output_type=pytesseract.Output.DICT)
    scores = [int(c) for c in data["conf"] if str(c).lstrip("-").isdigit() and int(c) >= 0]
    return sum(scores) / len(scores) if scores else 0.0


# ---------------------------------------------------------------------------
# 3. Command-line interface
# ---------------------------------------------------------------------------
def main() -> int:
    parser = argparse.ArgumentParser(description="Extract text from an image using OCR.")
    parser.add_argument("image", help="Path to image (jpg, png, bmp, tiff...)")
    parser.add_argument("--lang", default="eng", help="Tesseract language, e.g. eng, tam, eng+tam")
    parser.add_argument("--psm", type=int, default=3, help="Page segmentation mode (3=auto, 6=block, 7=line)")
    parser.add_argument("--output", help="Save extracted text to this .txt file")
    parser.add_argument("--no-preprocess", action="store_true", help="Run OCR on the raw image")
    parser.add_argument("--show", action="store_true", help="Display the preprocessed image")
    args = parser.parse_args()

    try:
        original = load_image(args.image)
    except FileNotFoundError as err:
        print(err, file=sys.stderr)
        return 1

    processed = original if args.no_preprocess else preprocess(original)

    if args.show:
        cv2.imshow("Preprocessed (press any key)", processed)
        cv2.waitKey(0)
        cv2.destroyAllWindows()

    try:
        text = extract_text(processed, args.lang, args.psm)
        confidence = average_confidence(processed, args.lang)
    except pytesseract.TesseractNotFoundError:
        print("Tesseract is not installed or not on PATH. See README.md.", file=sys.stderr)
        return 1

    print("=" * 50)
    print(text if text else "[No text detected]")
    print("=" * 50)
    print(f"Average confidence: {confidence:.1f}%")

    if args.output:
        Path(args.output).write_text(text, encoding="utf-8")
        print(f"Saved to {args.output}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
